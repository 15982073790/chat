<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/4/10
 * Time: 11:35
 */
namespace app\admin\model;

use think\Model;

class VisiterGroup extends Model
{
    protected $table = 'wolive_visiter_vgroup';
    public function setCreateTimeAttr()
    {

    }

    public function getCreateTimeAttr()
    {

    }
}