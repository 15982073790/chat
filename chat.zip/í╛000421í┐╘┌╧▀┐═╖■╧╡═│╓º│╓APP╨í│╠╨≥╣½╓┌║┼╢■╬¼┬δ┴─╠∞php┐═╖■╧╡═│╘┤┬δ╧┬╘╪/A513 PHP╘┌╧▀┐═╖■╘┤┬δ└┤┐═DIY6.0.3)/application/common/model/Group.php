<?php
/**
 * @copyright ©2021 来客PHP在线客服系统
 */

namespace app\common\model;

use think\Model;

class Group extends Model
{

}