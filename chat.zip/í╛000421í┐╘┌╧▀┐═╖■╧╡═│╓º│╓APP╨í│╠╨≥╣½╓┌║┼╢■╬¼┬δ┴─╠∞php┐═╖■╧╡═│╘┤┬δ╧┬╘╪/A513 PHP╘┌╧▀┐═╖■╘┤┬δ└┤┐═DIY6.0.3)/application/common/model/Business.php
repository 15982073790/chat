<?php
/**
 * @copyright ©2020 来客PHP在线客服系统
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2020/5/9
 * Time: 10:04
 */

namespace app\common\model;

use think\Model;

class Business extends Model
{

}