<?php
//技术支持微信:zrwx978
return [
    // 是否自动读取取插件钩子配置信息（默认是关闭）
    'autoload' => true,
    'fileflag'=>'install.lock'
];