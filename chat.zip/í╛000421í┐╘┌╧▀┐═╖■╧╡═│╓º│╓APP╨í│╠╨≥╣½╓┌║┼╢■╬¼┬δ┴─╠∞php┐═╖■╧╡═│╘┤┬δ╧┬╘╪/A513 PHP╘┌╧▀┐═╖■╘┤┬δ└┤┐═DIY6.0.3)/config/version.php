<?php
/**
 * Date: 2021/3/15 0015
 * 技术支持微信: zrwx978
 */
return ['LK_VERSION'=>'LK_DIY6.0.3'];