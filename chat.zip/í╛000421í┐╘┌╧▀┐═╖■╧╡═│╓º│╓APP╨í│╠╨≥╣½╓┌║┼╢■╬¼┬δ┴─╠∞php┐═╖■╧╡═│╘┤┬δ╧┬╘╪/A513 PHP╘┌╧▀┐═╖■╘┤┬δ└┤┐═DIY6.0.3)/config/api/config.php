<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/3/11
 * Time: 16:19
 */

return [
    'exception_handle' => 'app\common\exception\ExceptionHandler',
];